<footer class="page-footer footer footer-static footer-light navbar-border navbar-shadow">
    <div class="footer-copyright">
        <div class="container"><span>&copy; {{date("Y")}}"          <a href="#">^_^</a> All rights reserved.</span><span class="right hide-on-small-only">Design and Developed by <a href="#">^_^</a></span></div>
    </div>
</footer>
