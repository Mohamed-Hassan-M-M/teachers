<?php

return [

    'name' => 'Name',
    'junior' => 'Junior',
    'senior' => 'Senior',
    'expert' => 'Expert',
    'great' => 'Great',
    'rate' => 'Rate',
    'position' => 'Position',
    'mobile' => 'Mobile',
    'email' => 'Email',
    'image' => 'Image',
    'description' => 'Description',
    'password' => 'Password',
    'd and d' => 'Drag and drop a image here or click',
    'd and d r' => 'Drag and drop or click to replace',
    'remove' => 'Remove',
    'err' => 'Oops, something wrong happened.',
    'wrong format' => 'The image format is not allowed',
    'only' => 'only',
    'account' => 'Social Link',
    '' => '',
    '' => '',
    '' => '',

];
