<?php

return [

    'name' => 'Name',
    'type' => 'Type',
    'governmental' => 'Governmental',
    'special' => 'Special',
    '' => '',
    '' => '',
    '' => '',
    '' => '',
    '' => '',
    '' => '',
    '' => '',
    '' => '',
    '' => '',
    '' => '',
    '' => '',
    '' => '',
    '' => '',
    '' => '',
    '' => '',

];
